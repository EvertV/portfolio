        <footer class="footer">
            <div class="container">
                <span class="text-muted float-right">&copy; Evert Vanderstadt <?php echo date("Y");?></span>
            </div>
        </footer>
	</body>
</html>